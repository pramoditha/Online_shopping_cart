#include<stdio.h>
#include<string.h>
#include<stdlib.h>

// Structures for items and carts
char name[50],adress_state[50],adress_district[50],adress_street[50],adress_city[50],c;
int hs_no;
long long int ph_no;
struct electronic_item {
    int id;
    char item_name[50];
    char cpny_name[50];
    int price;
    int rating;
};

struct elctronic_cart {
    int id;
    char item_name[50];
    int price;
    int no_items;
    struct elctronic_cart *next;
};

struct book {
    int id;
    char item_name[50];
    char author_name[50];
    int price;
    int rating;
};

struct books_cart {
    int id;
    char item_name[50];
    int price;
    int no_items;
    struct books_cart *next;
};

struct shoes {
    int id;
    char brand[50];
    int price;
    int rating;
};

struct shoes_cart {
    int id;
    char brand[50];
    int price;
    int no_items;
    struct shoes_cart *next;
};

// Global variables for linked lists
struct elctronic_cart *ec_head = NULL;
struct books_cart *bc_head = NULL;
struct shoes_cart *sc_head = NULL;

// Function prototypes
void ele_item();
void book();
void shoe();
void delete_elec();
void delete_books();
void delete_shoes();
void change();
void bill();
void display_electronics();
void display_books();
void display_shoes();

// File pointers
FILE *fe, *fb, *fs, *fbill;

int main() {
    printf("-------------------------------*****Welcome to SR Online Shopping*****---------------------------------------------- ");
    int ch;
    char c;

    do {
        printf("\n\n\n1.Display all kinds of items available to buy\n2.Display the total number of items added\n3.Delete any selected item\n4.Change the quantity of any selected item\n5.Bill the items selected\n");
        printf("\nEnter your choice:");
        scanf("%d", &ch);

        switch(ch) {
            case 1:
                printf("\n1.Electronic Items\n");
                printf("2.Books\n");
                printf("3.Shoes\n");
                printf("Choose the kind of item you want to buy:");
                scanf("%d", &ch);

                switch(ch) {
                    case 1:
                        printf("Id\tItem\t\tCompany\t\tPrice\t\tRating\n");
                        ele_item();
                        break;
                    case 2:
                        printf("Id\tName\t\t\tAuthor Name\t\tPrice\t\tRating\n");
                        book();
                        break;
                    case 3:
                        printf("Id\tBrand\t\t\t\tPrice\t\tRating\n");
                        shoe();
                        break;
                }
                break;

            case 2:
                if (ec_head != NULL) {
                    printf("---------------Electronic items----------------------\n");
                    printf("Id\tName\t\tPrice\tNo.of items\n");
                    display_electronics();
                }

                if (bc_head != NULL) {
                    printf("---------------Books----------------------\n");
                    printf("Id\tName\t\tPrice\tNo.of items\n");
                    display_books();
                }

                if (sc_head != NULL) {
                    printf("---------------Shoes----------------------\n");
                    printf("Id\tName\t\tPrice\tNo.of items\n");
                    display_shoes();
                }
                break;

            case 3:
                if (ec_head != NULL) {
                    printf("---------------Electronic items----------------------\n");
                    printf("Id\tName\t\tPrice\tNo.of items\n");
                    display_electronics();
                }

                if (bc_head != NULL) {
                    printf("---------------Books----------------------\n");
                    printf("Id\tName\t\tPrice\tNo.of items\n");
                    display_books();
                }

                if (sc_head != NULL) {
                    printf("---------------Shoes----------------------\n");
                    printf("Id\tName\t\tPrice\tNo.of items\n");
                    display_shoes();
                }

                do {
                    printf("Enter the id of the product you wish to delete:");
                    scanf("%d", &ch);

                    switch (ch / 100) {
                        case 1:
                            delete_elec(ch);
                            break;
                        case 2:
                            delete_books(ch);
                            break;
                        case 3:
                            delete_shoes(ch);
                            break;
                    }

                    printf("\nEnter d to delete more items:");
                    scanf(" %c", &c);
                } while (c == 'd');
                break;

            case 4:
                if (ec_head != NULL) {
                    printf("---------------Electronic items----------------------\n");
                    printf("Id\tName\t\tPrice\tNo.of items\n");
                    display_electronics();
                }

                if (bc_head != NULL) {
                    printf("---------------Books----------------------\n");
                    printf("Id\tName\t\tPrice\tNo.of items\n");
                    display_books();
                }

                if (sc_head != NULL) {
                    printf("---------------Shoes----------------------\n");
                    printf("Id\tName\t\tPrice\tNo.of items\n");
                    display_shoes();
                }

                change();
                break;

            case 5:
                bill();
                exit(0);
                break;
        }

        printf("Press y to display options:");
        scanf(" %c", &c);
    } while (c == 'y');

    return 0;
}

void ele_item() {
    fe = fopen("D:/1st_year/IP/project/electronics.txt", "r");
    struct electronic_item e;
    
    while (fscanf(fe, "%d%s%s%d%d", &e.id, e.item_name, e.cpny_name, &e.price, &e.rating) != EOF) {
        printf("%d\t%s\t\t%s\t\t%d\t\t%d\n", e.id, e.item_name, e.cpny_name, e.price, e.rating);
    }
    
    fclose(fe);

    do {
        fe = fopen("D:/1st_year/IP/project/electronics.txt", "r");
        int eid, ne;
        
        printf("Enter the Id of the product you want to add to cart:");
        scanf("%d", &eid);

        while (fscanf(fe, "%d%s%s%d%d", &e.id, e.item_name, e.cpny_name, &e.price, &e.rating) != EOF) {
            if (eid == e.id) {
                printf("Enter The no.of %s you want to add:", e.item_name);
                scanf("%d", &ne);

                struct elctronic_cart *new_item = (struct elctronic_cart *)malloc(sizeof(struct elctronic_cart));
                new_item->id = e.id;
                strcpy(new_item->item_name, e.item_name);
                new_item->price = e.price;
                new_item->no_items = ne;
                new_item->next = NULL;

                if (ec_head == NULL) {
                    ec_head = new_item;
                } else {
                    struct elctronic_cart *temp = ec_head;
                    while (temp->next != NULL) {
                        temp = temp->next;
                    }
                    temp->next = new_item;
                }
                break;
            }
        }
        fclose(fe);
        printf("\n\nPress e if you want to add more products from electronics:");
        scanf(" %c", &c);
    } while (c == 'e');
}

void book() {
    fb = fopen("D:/1st_year/IP/project/books.txt", "r");
    struct book b;

    while (fscanf(fb, "%d%s%s%d%d", &b.id, b.item_name, b.author_name, &b.price, &b.rating) != EOF) {
        printf("%d\t%s\t\t%s\t\t%d\t\t%d\n", b.id, b.item_name, b.author_name, b.price, b.rating);
    }

    fclose(fb);

    do {
        fb = fopen("D:/1st_year/IP/project/books.txt", "r");
        int bid, nb;

        printf("Enter the Id of the product you want to add to cart:");
        scanf("%d", &bid);

        while (fscanf(fb, "%d%s%s%d%d", &b.id, b.item_name, b.author_name, &b.price, &b.rating) != EOF) {
            if (bid == b.id) {
                printf("Enter The no.of %s you want to add:", b.item_name);
                scanf("%d", &nb);

                struct books_cart *new_item = (struct books_cart *)malloc(sizeof(struct books_cart));
                new_item->id = b.id;
                strcpy(new_item->item_name, b.item_name);
                new_item->price = b.price;
                new_item->no_items = nb;
                new_item->next = NULL;

                if (bc_head == NULL) {
                    bc_head = new_item;
                } else {
                    struct books_cart *temp = bc_head;
                    while (temp->next != NULL) {
                        temp = temp->next;
                    }
                    temp->next = new_item;
                }
                break;
            }
        }
        fclose(fb);
        printf("\n\nPress b if you want to add more products from books:");
        scanf(" %c", &c);
    } while (c == 'b');
}

void shoe() {
    fs = fopen("D:/1st_year/IP/project/shoes.txt", "r");
    struct shoes s;

    while (fscanf(fs, "%d%s%d%d", &s.id, s.brand, &s.price, &s.rating) != EOF) {
        printf("%d\t%s\t\t\t%d\t\t%d\n", s.id, s.brand, s.price, s.rating);
    }

    fclose(fs);

    do {
        fs = fopen("D:/1st_year/IP/project/shoes.txt", "r");
        int sid, ns;

        printf("Enter the Id of the product you want to add to cart:");
        scanf("%d", &sid);

        while (fscanf(fs, "%d%s%d%d", &s.id, s.brand, &s.price, &s.rating) != EOF) {
            if (sid == s.id) {
                printf("Enter The no.of %s you want to add:", s.brand);
                scanf("%d", &ns);

                struct shoes_cart *new_item = (struct shoes_cart *)malloc(sizeof(struct shoes_cart));
                new_item->id = s.id;
                strcpy(new_item->brand, s.brand);
                new_item->price = s.price;
                new_item->no_items = ns;
                new_item->next = NULL;

                if (sc_head == NULL) {
                    sc_head = new_item;
                } else {
                    struct shoes_cart *temp = sc_head;
                    while (temp->next != NULL) {
                        temp = temp->next;
                    }
                    temp->next = new_item;
                }
                break;
            }
        }
        fclose(fs);
        printf("\n\nPress s if you want to add more products from shoes:");
        scanf(" %c", &c);
    } while (c == 's');
}

void delete_elec(int eid) {
    struct elctronic_cart *temp = ec_head, *prev = NULL;
    
    if (temp != NULL && temp->id == eid) {
        ec_head = temp->next;
        free(temp);
        return;
    }

    while (temp != NULL && temp->id != eid) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Product not found!\n");
        return;
    }

    prev->next = temp->next;
    free(temp);
}

void delete_books(int bid) {
    struct books_cart *temp = bc_head, *prev = NULL;
    
    if (temp != NULL && temp->id == bid) {
        bc_head = temp->next;
        free(temp);
        return;
    }

    while (temp != NULL && temp->id != bid) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Product not found!\n");
        return;
    }

    prev->next = temp->next;
    free(temp);
}

void delete_shoes(int sid) {
    struct shoes_cart *temp = sc_head, *prev = NULL;
    
    if (temp != NULL && temp->id == sid) {
        sc_head = temp->next;
        free(temp);
        return;
    }

    while (temp != NULL && temp->id != sid) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Product not found!\n");
        return;
    }

    prev->next = temp->next;
    free(temp);
}

void change() {
    int ch, no;
    struct elctronic_cart *temp1 = ec_head;
    struct books_cart *temp2 = bc_head;
    struct shoes_cart *temp3 = sc_head;
    char c;

    do {
        printf("\nPress 1 to change electronic item quantity\nPress 2 to change books item quantity\nPress 3 to change shoes item quantity:");
        scanf("%d", &ch);

        switch (ch) {
            case 1:
                printf("ID\tName\tPrice\tNo.of items\n");
                while (temp1 != NULL) {
                    printf("%d\t%s\t%d\t%d\n", temp1->id, temp1->item_name, temp1->price, temp1->no_items);
                    temp1 = temp1->next;
                }

                printf("Enter the ID to change the quantity:");
                scanf("%d", &ch);

                temp1 = ec_head;

                while (temp1 != NULL) {
                    if (temp1->id == ch) {
                        printf("Enter the new quantity:");
                        scanf("%d", &no);
                        temp1->no_items = no;
                    }
                    temp1 = temp1->next;
                }
                break;

            case 2:
                printf("ID\tName\tPrice\tNo.of items\n");
                while (temp2 != NULL) {
                    printf("%d\t%s\t%d\t%d\n", temp2->id, temp2->item_name, temp2->price, temp2->no_items);
                    temp2 = temp2->next;
                }

                printf("Enter the ID to change the quantity:");
                scanf("%d", &ch);

                temp2 = bc_head;

                while (temp2 != NULL) {
                    if (temp2->id == ch) {
                        printf("Enter the new quantity:");
                        scanf("%d", &no);
                        temp2->no_items = no;
                    }
                    temp2 = temp2->next;
                }
                break;

            case 3:
                printf("ID\tName\tPrice\tNo.of items\n");
                while (temp3 != NULL) {
                    printf("%d\t%s\t%d\t%d\n", temp3->id, temp3->brand, temp3->price, temp3->no_items);
                    temp3 = temp3->next;
                }

                printf("Enter the ID to change the quantity:");
                scanf("%d", &ch);

                temp3 = sc_head;

                while (temp3 != NULL) {
                    if (temp3->id == ch) {
                        printf("Enter the new quantity:");
                        scanf("%d", &no);
                        temp3->no_items = no;
                    }
                    temp3 = temp3->next;
                }
                break;
        }

        printf("\nPress c to change more items:");
        scanf(" %c", &c);
    } while (c == 'c');
}

void display_electronics() {
    struct elctronic_cart *temp = ec_head;

    while (temp != NULL) {
        printf("%d\t%s\t%d\t%d\n", temp->id, temp->item_name, temp->price, temp->no_items);
        temp = temp->next;
    }
}

void display_books() {
    struct books_cart *temp = bc_head;

    while (temp != NULL) {
        printf("%d\t%s\t%d\t%d\n", temp->id, temp->item_name, temp->price, temp->no_items);
        temp = temp->next;
    }
}

void display_shoes() {
    struct shoes_cart *temp = sc_head;

    while (temp != NULL) {
        printf("%d\t%s\t%d\t%d\n", temp->id, temp->brand, temp->price, temp->no_items);
        temp = temp->next;
    }
}

void bill() {
    fbill = fopen("D:/1st_year/IP/project/customer_record.txt", "a");
    
    // Customer information input
    printf("Please Enter your Name:");
    fscanf(stdin, "%s", name);
    fprintf(fbill, "\n\n--------------------------New Record------------------------------\n");
    fprintf(fbill, "Name:%s", name);
    
    printf("Enter Phone Number:");
    fscanf(stdin, "%lld", &ph_no);
    fprintf(fbill, "\nPhone Number:%lld", ph_no);
    
    printf("\nENTER ADDRESS");
    fprintf(fbill, "\nAddress:");
    
    printf("\nHouse Number:");
    fscanf(stdin, "%d", &hs_no);
    fprintf(fbill, "\n%d", hs_no);
    
    printf("\nStreet:");
    fscanf(stdin, "%s", adress_street);
    fprintf(fbill, "\n%s", adress_street);
    
    printf("\nTown/City:");
    fscanf(stdin, "%s", adress_city);
    fprintf(fbill, "\n%s", adress_city);
    
    printf("\nDistrict:");
    fscanf(stdin, "%s", adress_district);
    fprintf(fbill, "\n%s", adress_district);
    
    printf("\nState:");
    fscanf(stdin, "%s", adress_state);
    fprintf(fbill, "\n%s", adress_state);
    
    fprintf(fbill, "\n-------------------------------------Electronic Items------------------------------------\n");
    display_electronics();
    
    
    
    
    
    // Calculating total bill
    int total = 0;
    struct elctronic_cart *ec_current = ec_head;
    while (ec_current != NULL) {
        fprintf(fbill, "ID:%d\nItem_Name:%s\nPrice:%d\nNo_Items:%d\n", ec_current->id, ec_current->item_name, ec_current->price, ec_current->no_items);
        total += ec_current->price * ec_current->no_items;
        ec_current = ec_current->next;
    }
    fprintf(fbill, "\n-------------------------------------Books------------------------------------\n");
    display_books();
    
    struct books_cart *bc_current = bc_head;
    while (bc_current != NULL) {
        fprintf(fbill, "ID:%d\nBook_Name:%s\nPrice:%d\nNo_Items:%d\n", bc_current->id, bc_current->item_name, bc_current->price, bc_current->no_items);
        total += bc_current->price * bc_current->no_items;
        bc_current = bc_current->next;
    }
    fprintf(fbill, "\n-------------------------------------Shoes------------------------------------\n");
    display_shoes();
    struct shoes_cart *sc_current = sc_head;
    while (sc_current != NULL) {
        fprintf(fbill, "ID:%d\nBrand_Name:%s\nPrice:%d\nNo_Items:%d\n", sc_current->id, sc_current->brand, sc_current->price, sc_current->no_items);
        total += sc_current->price * sc_current->no_items;
        sc_current = sc_current->next;
    }
    
    fprintf(fbill, "\n*************************** Total_Bill:%d **************************************\n", total);
    fclose(fbill);
    
    printf("---------------------------------------------------------------\n");
    printf("TOTAL BILL=%d\n", total);
    printf("----------------------------------------------------------------\n");
    printf("------------------***Thank You For Buying %s***----------------", name);
}

